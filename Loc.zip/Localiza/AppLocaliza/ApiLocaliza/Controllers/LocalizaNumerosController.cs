﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ApiLocaliza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LocalizaNumerosController : ControllerBase
    {
        private readonly ILogger<LocalizaNumerosController> _logger;

        public LocalizaNumerosController(ILogger<LocalizaNumerosController> logger)
        {
            _logger = logger;
        }
   
        // GET <LocalizaNumerosController>/45
        [HttpGet("{numero}")]
        public IEnumerable<Numbers> Get(int numero)
        {
            List<Numbers> numbers = new List<Numbers>();

            try
            {
                for (int i = 1; i < numero; i++)
                {
                    //Verifica se é divisor 
                    if (numero % i == 0)
                    {
                        numbers.Add(new Numbers() { divisores = i });

                        //Verifica se é número primo
                        if (VerificarNumeroPrimo(i))
                            numbers.Add(new Numbers() { primos = i });
                    }
                }

                return numbers.ToArray();
            }
            catch (Exception ex)
            {

                throw ex;
            }           
        }

        // GET api/<LocalizaNumerosController>/5
        [HttpGet]
        public IEnumerable<Numbers> Get()
        {
            List<Numbers> numbers = new List<Numbers>();   

            return numbers.ToArray();
        }

        public static bool VerificarNumeroPrimo(int num)
        {
            try
            {
                for (int i = 2; i < num; i++)
                    if (num % i == 0)
                        return false;

                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }

    }
}

